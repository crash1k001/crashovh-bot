import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    TOKEN = os.getenv("BOT_TOKEN")
    SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
    SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
    DEFAULT_PREFIX = ">"
    OWNER_IDS = [919224897601949767] 

    # ── Lavalink ─────────────────────────────────────────────────
    # До 6 узлов Serenetia. Недоступные узлы автоматически скрываются
    # из мониторинга дашборда, а рабочие используются для failover.
    LAVALINK_NODES = [
        {
            "host": "lavalinkv4.serenetia.com",
            "port": 443,
            "password": "https://seretia.link/discord",
            "region": "us",
            "name": "Serenetia V4 SSL",
            "ssl": True,
        },
        {
            "host": "lavalinkv4.serenetia.com",
            "port": 80,
            "password": "https://seretia.link/discord",
            "region": "us",
            "name": "Serenetia V4",
            "ssl": False,
        },
        {
            "host": "lavav4.minecuta.com",
            "port": 2333,
            "password": "discord.gg/gKuXdHs",
            "region": "us",
            "name": "Serenetia Combined SSL",
            "ssl": False,
        },
        {
            "host": "nokia.vexanode.gg",
            "port": 19133,
            "password": "vexanode.cloud",
            "region": "us",
            "name": "Serenetia Combined",
            "ssl": False,
        },
    ]

    # ── Accent Color: None (Components V2) ──
    ACCENT_COLOR = None

    # ── Bot Info ──
    BOT_NAME = "SlideWay"
    SUPPORT_SERVER = "https://discord.gg/bKuEhCyYT5"
    WEBSITE = None

    # ── Dashboard ──
    DASHBOARD_ENABLED = os.getenv("DASHBOARD_ENABLED", "true").lower() == "true"
    DASHBOARD_URL = os.getenv("DASHBOARD_URL", "http://92.118.206.201:30242")

    # ── Logging Webhooks ──
    JOIN_LOG_WEBHOOK_URL = os.getenv("JOIN_LOG_WEBHOOK_URL")
    LEAVE_LOG_WEBHOOK_URL = os.getenv("LEAVE_LOG_WEBHOOK_URL")
    MUSIC_LOG_WEBHOOK_URL = os.getenv("MUSIC_LOG_WEBHOOK_URL")
    COMMAND_LOG_WEBHOOK_URL = os.getenv("COMMAND_LOG_WEBHOOK_URL")
    ERROR_LOG_WEBHOOK_URL = os.getenv("ERROR_LOG_WEBHOOK_URL")
    DASHBOARD_LOG_WEBHOOK_URL = os.getenv("DASHBOARD_LOG_WEBHOOK_URL")

    # ── Admin Panel Security ──
    ADMIN_PASSCODE = os.getenv("ADMIN_PASSCODE", "3832110")