# SlideWay Discord Bot

Музыкальный Discord-бот с веб-дашбордом на русском языке, поиском треков и управлением воспроизведением.

## Run & Operate

- `python main.py` — запуск Discord-бота и встроенного FastAPI-дашборда
- `pnpm run typecheck` — full typecheck across all packages
- `python -m py_compile main.py dashboard/app.py dashboard/oauth.py` — быстрая проверка Python-файлов
- Для запуска нужны переменные из исходного `.env` Discord-бота; секреты в чат не передавать.

## Stack

- Python 3.13, discord.py, FastAPI, Uvicorn
- Lavalink для воспроизведения музыки
- SQLite через aiosqlite для настроек, плейлистов и истории
- Jinja2-шаблоны и общий CSS в `dashboard/`

## Where things live

- `main.py` — точка входа бота SlideWay
- `cogs/` — внутренние модули бота; не изменялись при русификации интерфейса
- `dashboard/app.py` — API и маршруты дашборда
- `dashboard/templates/` — пользовательские страницы и тексты
- `dashboard/static/style.css` — общая тема и стили

## Architecture decisions

- Пользовательские cookie названы `SlideWay_session` и `SlideWay_admin_pin`, чтобы новая брендовая версия не пересекалась со старой Echo-сессией.
- Поиск возвращает thumbnail трека с сервера и использует YouTube-превью как запасной вариант, поэтому результат отображается с обложкой.
- Демо-плеер на главной остаётся браузерным предпросмотром и воспроизводит выбранное видео через YouTube IFrame API.

## Product

Пользователи могут авторизоваться через Discord, выбрать сервер, найти музыку, увидеть обложки и исполнителей в подсказках, поставить трек в очередь и управлять воспроизведением. Главная страница содержит рабочий предпросмотр «GUF — Письмо домой».

## User preferences

- Пользователь просит переводить только то, что видят обычные пользователи, не меняя внутреннюю логику модулей бота.
- Основное название продукта — SlideWay; Echo больше не используется в пользовательском брендинге.

## Gotchas

- Реальный поиск зависит от подключённой Lavalink-ноды; без неё дашборд явно показывает ошибку, а не подменяет результат.
- Для браузерного демо YouTube может потребовать первое нажатие по кнопке Play из-за политики autoplay.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
