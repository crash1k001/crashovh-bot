import discord
from discord.ext import commands
from discord import ui
from config import Config
import emojis
import datetime
import time
import asyncio
from utils.helpers import send_log_webhook


def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view


def make_mention_view(bot, author, prefix: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)

    uptime = int(time.time() - getattr(bot, "start_time", time.time()))
    h, m = uptime // 3600, (uptime % 3600) // 60
    lat = round(bot.latency * 1000)
    dash_url = getattr(Config, "DASHBOARD_URL", "http://localhost:3000")
    support_url = getattr(Config, "SUPPORT_SERVER", "")
    invite_url = discord.utils.oauth_url(bot.user.id, permissions=discord.Permissions(8)) if (bot and bot.user) else "https://discord.com"

    container.add_item(ui.TextDisplay(f"### {emojis.Echo} **Привет, {author.name}! Знакомься — {bot.user.name}**"))
    container.add_item(ui.TextDisplay(
        f"*{emojis.MUSIC} Премиальный студийный аудио-движок 320kbps, свои плейлисты и веб-консоль в реальном времени.*\n"
        f"{emojis.DOT} Нужна помощь? Напиши `{prefix}help` или `/help`, чтобы открыть консоль команд."
    ))
    container.add_item(ui.Separator())

    info_text = (
        f"### {emojis.CAT_CONFIG} **Быстрая настройка и телеметрия**\n"
        f"{emojis.DOT} **Префикс команд сервера:** `{prefix}`\n"
        f"{emojis.DOT} **Интерактивная помощь:** Напиши `{prefix}help` или `/help`\n"
        f"{emojis.DOT} **Голосовой режим 24/7:** Напиши `{prefix}247`, чтобы включить непрерывное воспроизведение\n"
        f"{emojis.DOT} **Задержка Gateway:** `{lat}ms`  •  **Аптайм:** `{h}ч {m}м`  •  **Серверов:** `{len(bot.guilds)}`\n"
        f"{emojis.DOT} **Веб-дашборд в реальном времени:** [Открыть консоль]({dash_url})"
    )
    container.add_item(ui.TextDisplay(info_text))
    container.add_item(ui.Separator())

    # Interactive Link Buttons Row
    row = ui.ActionRow()
    row.add_item(ui.Button(style=discord.ButtonStyle.link, label="Веб-дашборд", url=dash_url, emoji=emojis.Echo))
    if support_url and support_url.startswith("http"):
        row.add_item(ui.Button(style=discord.ButtonStyle.link, label="Сервер поддержки", url=support_url, emoji=emojis.INFO))
    row.add_item(ui.Button(style=discord.ButtonStyle.link, label="Пригласить бота", url=invite_url, emoji=emojis.SUCCESS))
    container.add_item(row)

    view.add_item(container)
    return view


class Events(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild or not self.bot.user:
            return
        if self.bot.user in message.mentions and not message.mention_everyone:
            content = message.content
            for u in message.mentions:
                content = content.replace(f"<@{u.id}>", "").replace(f"<@!{u.id}>", "")
            if not content.strip():
                try:
                    prefix = await self.bot.db.get_prefix(message.guild.id) or Config.DEFAULT_PREFIX
                    view = make_mention_view(self.bot, message.author, prefix)
                    await message.reply(view=view)
                except Exception as e:
                    print(f"[Mention Error] {e}")

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            perms = ", ".join(f"`{p}`" for p in error.missing_permissions)
            view = make_text_container(f"{emojis.ERROR} Тебе нужны права: {perms}.")
            return await ctx.reply(view=view)
        if isinstance(error, commands.BotMissingPermissions):
            perms = ", ".join(f"`{p}`" for p in error.missing_permissions)
            view = make_text_container(f"{emojis.ERROR} Мне нужны права: {perms}.")
            return await ctx.reply(view=view)
        if isinstance(error, commands.MissingRequiredArgument):
            text = (
                f"{emojis.ERROR} Отсутствует аргумент: `{error.param.name}`\n"
                f"Использование: `>{ctx.command.qualified_name} {ctx.command.signature}`"
            )
            view = make_text_container(text)
            return await ctx.reply(view=view)
        if isinstance(error, commands.CommandOnCooldown):
            view = make_text_container(f"Не так быстро! Попробуй снова через `{error.retry_after:.1f}с`.")
            return await ctx.reply(view=view)
        if isinstance(error, commands.NotOwner):
            view = make_text_container(f"{emojis.ERROR} Команда только для владельца.")
            return await ctx.reply(view=view)

        orig_error = getattr(error, "original", error)
        if isinstance(orig_error, (asyncio.TimeoutError, TimeoutError)):
            view = make_text_container(f"{emojis.ERROR} Время ожидания истекло. Попробуй ещё раз.")
            return await ctx.reply(view=view)
        if isinstance(orig_error, discord.NotFound) or (isinstance(orig_error, discord.HTTPException) and getattr(orig_error, "code", 0) == 10008):
            return

        view = make_text_container(f"{emojis.ERROR} Произошла ошибка:\n```py\n{str(error)[:500]}\n```")
        await ctx.reply(view=view)

        # Webhook Error Log (Components V2)
        try:
            cmd_content = ctx.message.content if (ctx.message and ctx.message.content) else f"/{ctx.command.qualified_name}"
            embed = {
                "title": f"{emojis.ERROR} Сбой команды",
                "fields": [
                    {"name": f"{emojis.TERMINAL} Команда", "value": f"`{cmd_content}`"},
                    {"name": f"{emojis.CAT_CONFIG} Сервер", "value": f"**{ctx.guild.name}** (`{ctx.guild.id}`)" if ctx.guild else "Личные сообщения"},
                    {"name": f"{emojis.USER_ICO} Пользователь", "value": f"{ctx.author.mention} (`{ctx.author.id}`)"},
                    {"name": f"{emojis.ERROR} Трассировка ошибки", "value": f"```py\n{str(error)[:800]}\n```"}
                ],
                "color": 16726072,  # #ff3838
                "thumbnail": {"url": str(ctx.author.display_avatar.url) if ctx.author else None},
                "footer": {"text": "Echo Логи • Отчёт о сбое"}
            }
            await send_log_webhook(Config.ERROR_LOG_WEBHOOK_URL, self.bot, embed)
        except Exception as e:
            print(f"[Webhook Log] Error sending error log: {e}")

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild):
        # Webhook Join Log (Components V2)
        try:
            owner_mention = guild.owner.mention if guild.owner else "Неизвестный владелец"
            owner_name = str(guild.owner) if guild.owner else "Неизвестно"
            embed = {
                "title": f"📥 Бот добавлен на сервер",
                "fields": [
                    {"name": "🏠 Название сервера", "value": f"**{guild.name}**"},
                    {"name": "🆔 ID сервера", "value": f"`{guild.id}`"},
                    {"name": f"{emojis.CROWN} Владелец сервера", "value": f"{owner_mention} (`{owner_name}`)"},
                    {"name": "👥 Количество участников", "value": f"`{guild.member_count:,}`"},
                    {"name": "📅 Дата создания", "value": f"<t:{int(guild.created_at.timestamp())}:F> (<t:{int(guild.created_at.timestamp())}:R>)"}
                ],
                "color": 3066993,  # #2ecc71 Green
                "thumbnail": {"url": str(guild.icon.url) if guild.icon else None},
                "footer": {"text": "Echo Логи • Администрирование системы"}
            }
            await send_log_webhook(Config.JOIN_LOG_WEBHOOK_URL, self.bot, embed)
        except Exception as e:
            print(f"[Webhook Log] Error sending join log: {e}")

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild):
        # Webhook Leave Log (Components V2)
        try:
            embed = {
                "title": f"📤 Бот покинул сервер",
                "fields": [
                    {"name": "🏠 Название сервера", "value": f"**{guild.name}**"},
                    {"name": "🆔 ID сервера", "value": f"`{guild.id}`"},
                    {"name": "👥 Финальное число участников", "value": f"`{guild.member_count:,}`"}
                ],
                "color": 15158332,  # #e74c3c Red
                "thumbnail": {"url": str(guild.icon.url) if guild.icon else None},
                "footer": {"text": "Echo Логи • Администрирование системы"}
            }
            await send_log_webhook(Config.LEAVE_LOG_WEBHOOK_URL, self.bot, embed)
        except Exception as e:
            print(f"[Webhook Log] Error sending leave log: {e}")

    @commands.Cog.listener()
    async def on_command(self, ctx):
        # Webhook Command Execution Log (Components V2)
        try:
            cmd_content = ctx.message.content if (ctx.message and ctx.message.content) else f"/{ctx.command.qualified_name}"
            embed = {
                "title": f"{emojis.TERMINAL} Команда выполнена",
                "fields": [
                    {"name": "💻 Команда", "value": f"`{cmd_content}`"},
                    {"name": f"{emojis.USER_ICO} Пользователь", "value": f"{ctx.author.mention} (`{ctx.author.name}` | ID: `{ctx.author.id}`)"},
                    {"name": "📍 Канал", "value": f"{ctx.channel.mention} (ID: `{ctx.channel.id}`)" if hasattr(ctx.channel, 'mention') else "ЛС"},
                    {"name": "🏠 Сервер", "value": f"**{ctx.guild.name}** (ID: `{ctx.guild.id}`)" if ctx.guild else "Личные сообщения"}
                ],
                "color": 10181046,  # #9b59b6 Purple
                "thumbnail": {"url": str(ctx.author.display_avatar.url) if ctx.author else None},
                "footer": {"text": "Echo Логи • Монитор команд"}
            }
            await send_log_webhook(Config.COMMAND_LOG_WEBHOOK_URL, self.bot, embed)
        except Exception as e:
            print(f"[Webhook Log] Error sending command log: {e}")


async def setup(bot):
    await bot.add_cog(Events(bot))