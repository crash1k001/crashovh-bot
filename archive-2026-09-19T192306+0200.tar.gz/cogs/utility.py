import discord
from discord.ext import commands
from discord import ui
from config import Config
import emojis


def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view


def make_image_layout(title: str, image_url: str, download_url: str = None) -> ui.LayoutView:
    """Собрать блок с заголовком и большим изображением через Section+Thumbnail."""
    layout = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(f"### {title}"))
    container.add_item(ui.Separator())

    # Use MediaGallery with proper items
    try:
        gallery = ui.MediaGallery()
        gallery.add_item(media=discord.UnfurledMediaItem(url=image_url))
        container.add_item(gallery)
    except Exception:
        # Fallback: use Section with Thumbnail if MediaGallery fails
        section = ui.Section(
            accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=image_url))
        )
        section.add_item(ui.TextDisplay(f"[Открыть изображение полностью]({image_url})"))
        container.add_item(section)

    if download_url:
        container.add_item(ui.Separator())
        row = ui.ActionRow()
        row.add_item(ui.Button(label="Открыть изображение", url=download_url, style=discord.ButtonStyle.link))
        container.add_item(row)

    layout.add_item(container)
    return layout


class Utility(commands.Cog, name="Utility"):
    """Утилиты."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="avatar", aliases=["av", "pfp"])
    async def avatar(self, ctx, *, member: discord.Member = None):
        """Показать аватар пользователя."""
        m = member or ctx.author
        url = m.display_avatar.with_size(1024).url
        layout = make_image_layout(f"Аватар {m.display_name}", url, url)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="banner")
    async def banner(self, ctx, *, member: discord.Member = None):
        """Показать баннер пользователя."""
        m = member or ctx.author
        user = await self.bot.fetch_user(m.id)
        if not user.banner:
            view = make_text_container(f"{emojis.ERROR} У {m.display_name} нет баннера.")
            return await ctx.reply(view=view)
        url = user.banner.with_size(1024).url
        layout = make_image_layout(f"Баннер {m.display_name}", url, url)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="servericon", aliases=["sicon"])
    async def servericon(self, ctx):
        """Показать иконку сервера."""
        if not ctx.guild.icon:
            view = make_text_container(f"{emojis.ERROR} У сервера нет иконки.")
            return await ctx.reply(view=view)
        url = ctx.guild.icon.with_size(1024).url
        layout = make_image_layout(ctx.guild.name, url, url)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="serverbanner", aliases=["sbanner"])
    async def serverbanner(self, ctx):
        """Показать баннер сервера."""
        if not ctx.guild.banner:
            view = make_text_container(f"{emojis.ERROR} У сервера нет баннера.")
            return await ctx.reply(view=view)
        url = ctx.guild.banner.with_size(1024).url
        layout = make_image_layout(f"Баннер сервера {ctx.guild.name}", url, url)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="userinfo", aliases=["ui", "whois"])
    async def userinfo(self, ctx, member: discord.Member = None):
        """Показать информацию о пользователе."""
        m = member or ctx.author

        text = (
            f"### {m.display_name}\n"
            f"```yaml\n"
            f"Имя           : {m}\n"
            f"ID            : {m.id}\n"
            f"Никнейм       : {m.nick or 'Нет'}\n"
            f"Высшая роль   : {m.top_role.name}\n"
            f"Бот           : {'Да' if m.bot else 'Нет'}\n"
            f"Ролей         : {len(m.roles) - 1}\n"
            f"```"
        )
        view = make_text_container(text)
        await ctx.reply(view=view)

    @commands.hybrid_command(name="serverinfo", aliases=["si"])
    async def serverinfo(self, ctx):
        """Показать информацию о сервере."""
        g = ctx.guild
        bots = sum(1 for m in g.members if m.bot)
        humans = g.member_count - bots
        text = (
            f"### {g.name}\n"
            f"```yaml\n"
            f"ID            : {g.id}\n"
            f"Владелец      : {g.owner}\n"
            f"Участников    : {g.member_count}\n"
            f"Людей         : {humans}\n"
            f"Ботов         : {bots}\n"
            f"Каналов       : {len(g.text_channels) + len(g.voice_channels)}\n"
            f"Ролей         : {len(g.roles)}\n"
            f"Бустов        : {g.premium_subscription_count} (Уровень {g.premium_tier})\n"
            f"```"
        )
        view = make_text_container(text)
        await ctx.reply(view=view)


async def setup(bot):
    await bot.add_cog(Utility(bot))