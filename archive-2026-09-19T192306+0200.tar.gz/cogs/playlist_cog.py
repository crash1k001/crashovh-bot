import discord
from discord.ext import commands
from discord import ui
import emojis
import time
import asyncio
from cogs.music import get_source_emoji_from_uri, format_duration, LavalinkVoiceClient

def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view

class Playlist(commands.Cog, name="Playlist"):
    """Команды плейлистов — управление пользовательскими плейлистами."""

    def __init__(self, bot):
        self.bot = bot

    async def _resolve_track(self, sem, player, track_title: str, track_uri: str, stagger: float = 0.0):
        if stagger > 0:
            await asyncio.sleep(stagger)
        async with sem:
            search_query = track_uri if track_uri else f"ytsearch:{track_title}"
            for attempt in range(2):
                try:
                    results = await player.node.get_tracks(search_query)
                    if (not results or not results.tracks) and ("spotify.com/" in search_query or "spotify:" in search_query):
                        fallback_query = f"ytsearch:{track_title}"
                        results = await player.node.get_tracks(fallback_query)
                    if results and results.tracks:
                        return results.tracks[0]
                except Exception as e:
                    print(f"[PlaylistCog] Попытка {attempt+1} не удалась для '{track_title}': {e}")
                if attempt == 0:
                    await asyncio.sleep(0.25)
            return None

    # Base commands
    @commands.hybrid_group(name="playlist", aliases=["pl"], invoke_without_command=True)
    @commands.guild_only()
    async def playlist_group(self, ctx):
        """Группа команд плейлистов."""
        text = (
            f"### {emojis.CAT_MUSIC} Команды плейлистов\n"
            f"Управляй своими плейлистами и воспроизводи их.\n\n"
            f"{emojis.DOT} `{ctx.prefix}playlist create <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist delete <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist rename <old_name> <new_name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist list`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist show <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist add <name> [song]`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist remove <name> <song_index>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist public <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist private <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist play <name>`\n"
            f"{emojis.DOT} `{ctx.prefix}playlist playcode <code>`"
        )
        await ctx.reply(view=make_text_container(text))

    @playlist_group.command(name="create")
    @commands.guild_only()
    async def create_pl(self, ctx, *, name: str):
        """Создать новый плейлист."""
        name = name.strip()
        if not name:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Название не может быть пустым."))
        
        # Check if already exists
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист с названием `{name}` уже существует."))

        await self.bot.db.create_playlist(ctx.author.id, name)
        await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} Плейлист **{name}** создан!"))

    @playlist_group.command(name="delete")
    @commands.guild_only()
    async def delete_pl(self, ctx, *, name: str):
        """Удалить существующий плейлист."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))

        playlist_id = existing[0]
        await self.bot.db.delete_playlist(ctx.author.id, playlist_id)
        await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} Плейлист **{name}** удалён."))

    @playlist_group.command(name="rename")
    @commands.guild_only()
    async def rename_pl(self, ctx, old_name: str, new_name: str):
        """Переименовать существующий плейлист."""
        old_name = old_name.strip()
        new_name = new_name.strip()
        
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, old_name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{old_name}` не найден."))
            
        # Check if new name already exists
        conflict = await self.bot.db.get_playlist_by_name(ctx.author.id, new_name)
        if conflict:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист с названием `{new_name}` уже существует."))

        playlist_id = existing[0]
        await self.bot.db.rename_playlist(ctx.author.id, playlist_id, new_name)
        await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} Плейлист **{old_name}** переименован в **{new_name}**."))

    @playlist_group.command(name="list")
    @commands.guild_only()
    async def list_pls(self, ctx):
        """Показать все твои плейлисты."""
        playlists = await self.bot.db.get_playlists(ctx.author.id)
        if not playlists:
            return await ctx.reply(view=make_text_container(f"{emojis.INFO} У тебя пока нет плейлистов. Создай один командой `{ctx.prefix}playlist create <name>`."))

        desc = ""
        for p in playlists:
            desc += f"{emojis.DOT} **{p[1]}** — `{p[3]}` треков\n"
        
        text = f"### {emojis.MYMUSIC} Твои плейлисты\n{desc}"
        await ctx.reply(view=make_text_container(text))

    @playlist_group.command(name="show")
    @commands.guild_only()
    async def show_pl(self, ctx, *, name: str):
        """Показать треки в плейлисте."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))

        playlist_id, pl_name, *_ = existing
        tracks = await self.bot.db.get_playlist_tracks(playlist_id)
        if not tracks:
            return await ctx.reply(view=make_text_container(f"{emojis.INFO} Плейлист **{pl_name}** пуст."))

        desc = ""
        for i, t in enumerate(tracks[:20]):
            src = get_source_emoji_from_uri(t[3])
            desc += f"`{i+1}.` {src} **{t[1]}**\n"
            
        text = f"### {emojis.MUSIC} Плейлист: {pl_name}\n{desc}"
        if len(tracks) > 20:
            text += f"\n-# И ещё `{len(tracks) - 20}`..."
        await ctx.reply(view=make_text_container(text))

    @playlist_group.command(name="add")
    @commands.guild_only()
    async def add_to_pl(self, ctx, name: str, *, query: str = None):
        """Добавить трек в плейлист. По умолчанию — текущий трек."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))

        playlist_id, pl_name, *_ = existing
        music_cog = self.bot.get_cog("Music")

        # If query is not specified, get currently playing track
        if not query:
            if not music_cog or not music_cog.lavalink:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Музыкальная система недоступна."))
            player = music_cog.lavalink.player_manager.get(ctx.guild.id)
            if not player or not player.current:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Сейчас ничего не играет на этом сервере. Укажи название или ссылку трека для добавления."))
            track = player.current
            await self.bot.db.add_to_playlist(playlist_id, track.title, track.author, track.uri, track.identifier)
            return await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} **{track.title}** добавлен в плейлист **{pl_name}**!"))

        # Otherwise, search and add
        if not music_cog or not music_cog.lavalink:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Музыкальная система недоступна."))
        player = music_cog.lavalink.player_manager.create(ctx.guild.id)
        search_query = query.strip()
        if not (search_query.startswith("http://") or search_query.startswith("https://")):
            search_query = f"ytsearch:{search_query}"
        
        loading_msg = await ctx.reply(view=make_text_container(f"{emojis.LOADING} Ищу трек..."))
        try:
            results = await player.node.get_tracks(search_query)
            if not results or not results.tracks:
                return await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Ничего не найдено по запросу **{query}**."))
            track = results.tracks[0]
            await self.bot.db.add_to_playlist(playlist_id, track.title, track.author, track.uri, track.identifier)
            await loading_msg.edit(view=make_text_container(f"{emojis.SUCCESS} **{track.title}** добавлен в плейлист **{pl_name}**!"))
        except Exception as e:
            await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Не удалось добавить трек: `{e}`"))

    @playlist_group.command(name="remove")
    @commands.guild_only()
    async def remove_from_pl(self, ctx, name: str, index: int):
        """Удалить трек из плейлиста по индексу (показан в команде show)."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))

        playlist_id, pl_name, *_ = existing
        tracks = await self.bot.db.get_playlist_tracks(playlist_id)
        if not tracks:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист **{pl_name}** пуст."))

        if index < 1 or index > len(tracks):
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Неверный индекс. Используй `{ctx.prefix}playlist show {pl_name}`, чтобы увидеть индексы."))

        track_to_remove = tracks[index - 1]
        track_id = track_to_remove[0]
        track_title = track_to_remove[1]
        
        await self.bot.db.remove_from_playlist(playlist_id, track_id)
        await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} **{track_title}** удалён из плейлиста **{pl_name}**."))

    @playlist_group.command(name="public")
    @commands.guild_only()
    async def public_pl(self, ctx, *, name: str):
        """Сделать плейлист публичным."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))
            
        playlist_id = existing[0]
        await self.bot.db.set_playlist_privacy(ctx.author.id, playlist_id, True)
        code = await self.bot.db.ensure_playlist_code(playlist_id)
        await ctx.reply(view=make_text_container(
            f"{emojis.SUCCESS} Плейлист **{name}** теперь **публичный**!\n"
            f"Код для доступа: `{code}`"
        ))

    @playlist_group.command(name="private")
    @commands.guild_only()
    async def private_pl(self, ctx, *, name: str):
        """Сделать плейлист приватным."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))
            
        playlist_id = existing[0]
        await self.bot.db.set_playlist_privacy(ctx.author.id, playlist_id, False)
        await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} Плейлист **{name}** теперь **приватный**."))

    @playlist_group.command(name="playcode", aliases=["code"])
    @commands.guild_only()
    async def playcode_pl(self, ctx, code: str):
        """Воспроизвести публичный плейлист по коду доступа."""
        code = code.strip().upper()
        if not code:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Укажи код доступа к плейлисту."))

        playlist = await self.bot.db.get_playlist_by_code(code)
        if not playlist:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Публичный плейлист с кодом `{code}` не найден."))

        playlist_id, pl_name, owner_id, track_count, is_public, _ = playlist
        
        is_owner = ctx.author.id == owner_id
        if not is_public and not is_owner:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Этот плейлист приватный."))

        tracks = await self.bot.db.get_playlist_tracks(playlist_id)
        if not tracks:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист **{pl_name}** пуст."))

        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Музыкальная система недоступна."))

        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Ты должен находиться в голосовом канале."))

        vc = ctx.author.voice.channel
        player = music_cog.lavalink.player_manager.create(ctx.guild.id)

        if not ctx.guild.voice_client:
            perms = vc.permissions_for(ctx.guild.me)
            if not perms.connect or not perms.speak:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Мне нужны права Подключение и Говорить в твоём голосовом канале."))
            player.store("channel", ctx.channel.id)
            try:
                await vc.connect(cls=LavalinkVoiceClient, self_deaf=True)
                await asyncio.sleep(0.5)
            except Exception as e:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Не удалось подключиться: `{e}`"))
        elif ctx.guild.voice_client.channel != vc:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Ты должен быть в моём голосовом канале."))

        loading_msg = await ctx.reply(view=make_text_container(f"{emojis.LOADING} Загружаю треки из плейлиста **{pl_name}**..."))

        # Resolve tracks in parallel with rate limit safety
        sem = asyncio.Semaphore(3)
        tasks = [
            self._resolve_track(sem, player, t[1], t[3], stagger=i * 0.15)
            for i, t in enumerate(tracks)
        ]
        resolved_tracks = await asyncio.gather(*tasks)

        added_count = 0
        for track in resolved_tracks:
            if track:
                player.add(requester=ctx.author.id, track=track)
                added_count += 1

        if added_count == 0:
            return await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Не удалось загрузить ни одного трека из плейлиста."))

        if not player.is_playing:
            try:
                await player.play()
            except Exception as e:
                return await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Ошибка воспроизведения: `{e}`"))

        await self.bot.db.record_playlist_play(playlist_id)
        await music_cog._notify_dashboard(ctx.guild.id)
        await loading_msg.edit(view=make_text_container(f"{emojis.SUCCESS} В очередь добавлено `{added_count}` треков из плейлиста **{pl_name}**!"))

    @playlist_group.command(name="play")
    @commands.guild_only()
    async def play_pl(self, ctx, *, name: str):
        """Воспроизвести пользовательский плейлист."""
        name = name.strip()
        existing = await self.bot.db.get_playlist_by_name(ctx.author.id, name)
        if not existing:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист `{name}` не найден."))

        playlist_id, pl_name, *_ = existing
        tracks = await self.bot.db.get_playlist_tracks(playlist_id)
        if not tracks:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Плейлист **{pl_name}** пуст."))

        music_cog = self.bot.get_cog("Music")
        if not music_cog:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Музыкальная система недоступна."))

        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Ты должен находиться в голосовом канале."))

        vc = ctx.author.voice.channel
        player = music_cog.lavalink.player_manager.create(ctx.guild.id)

        if not ctx.guild.voice_client:
            perms = vc.permissions_for(ctx.guild.me)
            if not perms.connect or not perms.speak:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Мне нужны права Подключение и Говорить в твоём голосовом канале."))
            player.store("channel", ctx.channel.id)
            try:
                await vc.connect(cls=LavalinkVoiceClient, self_deaf=True)
                await asyncio.sleep(0.5)
            except Exception as e:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Не удалось подключиться: `{e}`"))
        elif ctx.guild.voice_client.channel != vc:
            return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Ты должен быть в моём голосовом канале."))

        loading_msg = await ctx.reply(view=make_text_container(f"{emojis.LOADING} Загружаю треки из плейлиста **{pl_name}**..."))

        # Resolve tracks in parallel with rate limit safety
        sem = asyncio.Semaphore(3)
        tasks = [
            self._resolve_track(sem, player, t[1], t[3], stagger=i * 0.15)
            for i, t in enumerate(tracks)
        ]
        resolved_tracks = await asyncio.gather(*tasks)

        added_count = 0
        for track in resolved_tracks:
            if track:
                player.add(requester=ctx.author.id, track=track)
                added_count += 1

        if added_count == 0:
            return await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Не удалось загрузить ни одного трека из плейлиста."))

        if not player.is_playing:
            try:
                await player.play()
            except Exception as e:
                return await loading_msg.edit(view=make_text_container(f"{emojis.ERROR} Ошибка воспроизведения: `{e}`"))

        await self.bot.db.record_playlist_play(playlist_id)
        await music_cog._notify_dashboard(ctx.guild.id)
        await loading_msg.edit(view=make_text_container(f"{emojis.SUCCESS} В очередь добавлено `{added_count}` треков из плейлиста **{pl_name}**!"))

async def setup(bot):
    await bot.add_cog(Playlist(bot))
