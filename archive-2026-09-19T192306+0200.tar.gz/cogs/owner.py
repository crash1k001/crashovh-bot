"""
cogs/owner.py — Owner-only bot management commands.
Hidden from the public help menu (see cogs/info.py filtering).
"""

import discord
from discord.ext import commands
from discord import ui
import time
import platform
import psutil
import lavalink

import emojis
from config import Config


def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view


class Owner(commands.Cog, name="Owner"):
    """Утилиты только для владельца. Скрыто из публичного меню помощи."""

    def __init__(self, bot):
        self.bot = bot

    # ── Cog / extension management ─────────────────────────────────

    @commands.command(name="reload", hidden=True)
    @commands.is_owner()
    async def reload_cog(self, ctx, cog: str):
        try:
            await self.bot.reload_extension(f"cogs.{cog}")
            view = make_text_container(f"{emojis.RELOAD} `{cog}` перезагружен.")
        except commands.ExtensionNotLoaded:
            view = make_text_container(f"{emojis.ERROR} `{cog}` не загружен.")
        except Exception as e:
            view = make_text_container(f"{emojis.ERROR} Не удалось перезагрузить `{cog}`:\n```py\n{e}\n```")
        await ctx.reply(view=view)

    @commands.command(name="load", hidden=True)
    @commands.is_owner()
    async def load_cog(self, ctx, cog: str):
        try:
            await self.bot.load_extension(f"cogs.{cog}")
            view = make_text_container(f"{emojis.CHECK_ICO} `{cog}` загружен.")
        except commands.ExtensionAlreadyLoaded:
            view = make_text_container(f"{emojis.ERROR} `{cog}` уже загружен.")
        except Exception as e:
            view = make_text_container(f"{emojis.ERROR} Не удалось загрузить `{cog}`:\n```py\n{e}\n```")
        await ctx.reply(view=view)

    @commands.command(name="unload", hidden=True)
    @commands.is_owner()
    async def unload_cog(self, ctx, cog: str):
        if cog == "owner":
            view = make_text_container(f"{emojis.ERROR} Нельзя выгрузить ког владельца.")
            return await ctx.reply(view=view)
        try:
            await self.bot.unload_extension(f"cogs.{cog}")
            view = make_text_container(f"{emojis.CHECK_ICO} `{cog}` выгружен.")
        except commands.ExtensionNotLoaded:
            view = make_text_container(f"{emojis.ERROR} `{cog}` не загружен.")
        await ctx.reply(view=view)

    @commands.command(name="sync", hidden=True)
    @commands.is_owner()
    async def sync_cmds(self, ctx, scope: str = "guild"):
        view = make_text_container(f"{emojis.LOADING} Синхронизация...")
        msg = await ctx.reply(view=view)
        try:
            if scope.lower() == "global":
                synced = await self.bot.tree.sync()
                view = make_text_container(f"{emojis.CHECK_ICO} Синхронизировано `{len(synced)}` команд(ы) глобально. (Может занять до 1 часа, чтобы применилось на всех серверах).")
            elif scope.lower() == "clear":
                self.bot.tree.clear_commands(guild=ctx.guild)
                await self.bot.tree.sync(guild=ctx.guild)
                view = make_text_container(f"{emojis.CHECK_ICO} Все слэш-команды этого сервера очищены! Дубликаты команд скоро исчезнут.")
            elif scope.lower() == "clearall":
                cleared_count = 0
                for g in self.bot.guilds:
                    try:
                        self.bot.tree.clear_commands(guild=g)
                        await self.bot.tree.sync(guild=g)
                        cleared_count += 1
                    except Exception:
                        pass
                view = make_text_container(f"{emojis.CHECK_ICO} Слэш-команды успешно очищены на `{cleared_count}` сервере(ах)!")
            else:
                self.bot.tree.copy_global_to(guild=ctx.guild)
                synced = await self.bot.tree.sync(guild=ctx.guild)
                view = make_text_container(f"{emojis.CHECK_ICO} Синхронизировано `{len(synced)}` команд(ы) на этот сервер мгновенно!")
        except Exception as e:
            view = make_text_container(f"{emojis.ERROR} Синхронизация не удалась:\n```py\n{e}\n```")
        await msg.edit(view=view)

    # ── Bot control ──────────────────────────────────────────────

    @commands.command(name="shutdown", aliases=["die", "poweroff"], hidden=True)
    @commands.is_owner()
    async def shutdown(self, ctx):
        view = make_text_container(f"{emojis.SHUTDOWN} Выключаюсь...")
        await ctx.reply(view=view)
        await self.bot.close()

    @commands.command(name="setstatus", hidden=True)
    @commands.is_owner()
    async def setstatus(self, ctx, status: str):
        status_map = {
            "online": discord.Status.online,
            "idle": discord.Status.idle,
            "dnd": discord.Status.dnd,
            "invisible": discord.Status.invisible,
        }
        s = status_map.get(status.lower())
        if not s:
            view = make_text_container(f"{emojis.ERROR} Неверный статус. Используй: online, idle, dnd, invisible.")
            return await ctx.reply(view=view)
        self.bot.current_status = s
        await self.bot.change_presence(status=s, activity=self.bot.activity)
        view = make_text_container(f"{emojis.CHECK_ICO} Статус установлен: `{status}`.")
        await ctx.reply(view=view)

    @commands.command(name="setactivity", hidden=True)
    @commands.is_owner()
    async def setactivity(self, ctx, *, text: str):
        if text.lower() == "auto":
            self.bot.auto_presence = True
            view = make_text_container(f"{emojis.CHECK_ICO} Автосмена статуса активности включена.")
        else:
            self.bot.auto_presence = False
            await self.bot.change_presence(
                activity=discord.Activity(type=discord.ActivityType.listening, name=text),
                status=self.bot.current_status
            )
            view = make_text_container(f"{emojis.CHECK_ICO} Активность установлена: `{text}`. Автосмена статуса отключена (используй `>setactivity auto`, чтобы включить).")
        await ctx.reply(view=view)

    # ── Diagnostics ──────────────────────────────────────────────

    @commands.command(name="eval", aliases=["ev"], hidden=True)
    @commands.is_owner()
    async def eval_cmd(self, ctx, *, code: str):
        code = code.strip("`")
        if code.startswith("py"):
            code = code[2:].strip()

        env = {
            "bot": self.bot,
            "ctx": ctx,
            "discord": discord,
            "lavalink": lavalink,  # <-- wavelink hatake lavalink paya
        }
        try:
            result = eval(code, env)
            if hasattr(result, "__await__"):
                result = await result
            view = make_text_container(f"{emojis.CHECK_ICO} ```py\n{result}\n```")
        except Exception as e:
            view = make_text_container(f"{emojis.ERROR} ```py\n{type(e).__name__}: {e}\n```")
        await ctx.reply(view=view)

    @commands.command(name="nodeinfo", hidden=True)
    @commands.is_owner()
    async def nodeinfo(self, ctx):
        # lavalink.py vich client through nodes mildiyan ne
        lavalink_client = self.bot.lavalink

        if not lavalink_client or not lavalink_client.node_manager.nodes:
            view = make_text_container(f"{emojis.ERROR} Ноды Lavalink не настроены.")
            return await ctx.reply(view=view)

        lines = []
        for node in lavalink_client.node_manager.nodes:
            # Node available hai ke nahi check karo
            status = "Подключена" if node.available else "Отключена"
            # Kitne players chalde ne os node te
            player_count = len(node.players) if hasattr(node, "players") else node.stats.playing_players if node.stats else "?"

            # Node da name/region
            name = node.name or node.host
            lines.append(
                f"{emojis.DOT} **{name}** — `{status}` "
                f"({player_count} player(s))"
            )

        text = f"### {emojis.INFO} Ноды Lavalink\n" + "\n".join(lines)
        await ctx.reply(view=make_text_container(text))

    @commands.command(name="sysinfo", hidden=True)
    @commands.is_owner()
    async def sysinfo(self, ctx):
        uptime = int(time.time() - self.bot.start_time)
        h, rem = divmod(uptime, 3600)
        m, s = divmod(rem, 60)

        process = psutil.Process()
        mem = process.memory_info().rss / 1024 / 1024

        text = (
            f"### {emojis.RAM} Информация о системе\n"
            f"{emojis.DOT} **Python:** `{platform.python_version()}`\n"
            f"{emojis.DOT} **discord.py:** `{discord.__version__}`\n"
            f"{emojis.DOT} **Lavalink.py:** `{lavalink.__version__}`\n"
            f"{emojis.DOT} **CPU:** `{psutil.cpu_percent()}%`\n"
            f"{emojis.DOT} **Память:** `{mem:.1f} MB`\n"
            f"{emojis.DOT} **Аптайм:** `{h}ч {m}м {s}с`\n"
            f"{emojis.DOT} **Серверов:** `{len(self.bot.guilds)}`\n"
            f"{emojis.DOT} **Пользователей:** `{sum(g.member_count or 0 for g in self.bot.guilds)}`"
        )
        await ctx.reply(view=make_text_container(text))

    @commands.command(name="dm", hidden=True)
    @commands.is_owner()
    async def dm_user(self, ctx, user: discord.User, *, message: str):
        try:
            await user.send(view=make_text_container(message))
            view = make_text_container(f"{emojis.CHECK_ICO} Сообщение отправлено {user.mention}.")
        except discord.Forbidden:
            view = make_text_container(f"{emojis.ERROR} Не удалось отправить ЛС {user.mention} (закрыты ЛС).")
        except Exception as e:
            view = make_text_container(f"{emojis.ERROR} Ошибка: `{e}`")
        await ctx.reply(view=view)

    @commands.command(name="guilds", aliases=["servers"], hidden=True)
    @commands.is_owner()
    async def guilds_list(self, ctx):
        lines = []
        for g in sorted(self.bot.guilds, key=lambda x: x.member_count or 0, reverse=True)[:25]:
            lines.append(f"{emojis.DOT} **{g.name}** — `{g.member_count}` участников (`{g.id}`)")

        text = f"### {emojis.INFO} Серверы ({len(self.bot.guilds)})\n" + "\n".join(lines)
        await ctx.reply(view=make_text_container(text))

    @commands.command(name="maintenance", aliases=["maint"], hidden=True)
    @commands.is_owner()
    async def toggle_maintenance(self, ctx, state: str = "check"):
        state = state.lower().strip()
        if state in ("on", "enable", "1", "true"):
            await self.bot.db.set_bot_setting("maintenance_mode", "1")
            self.bot.maintenance_mode = True
            await self.bot.db.log_audit_action(
                user_id=ctx.author.id,
                username=str(ctx.author),
                title="🛠️ Режим обслуживания веб-дашборда ВКЛЮЧЁН",
                description="Веб-дашборд отключён для пользователей через команду Discord.",
                color=0xef4444
            )
            view = make_text_container(
                f"### {emojis.WARNING} Обслуживание веб-дашборда: **ВКЛЮЧЕНО**\n"
                f"{emojis.DOT} Веб-плеер и публичный доступ к дашборду теперь **ОТКЛЮЧЕНЫ** для пользователей.\n"
                f"{emojis.DOT} Владельцы всё ещё могут заходить в Админ-панель (`/admin`)."
            )
        elif state in ("off", "disable", "0", "false"):
            await self.bot.db.set_bot_setting("maintenance_mode", "0")
            self.bot.maintenance_mode = False
            await self.bot.db.log_audit_action(
                user_id=ctx.author.id,
                username=str(ctx.author),
                title="🟢 Режим обслуживания веб-дашборда ВЫКЛЮЧЕН",
                description="Веб-дашборд включён для всех пользователей через команду Discord.",
                color=0x10b981
            )
            view = make_text_container(
                f"### {emojis.SUCCESS} Обслуживание веб-дашборда: **ВЫКЛЮЧЕНО**\n"
                f"{emojis.DOT} Веб-плеер и публичный доступ к дашборду теперь **ДОСТУПНЫ** всем пользователям."
            )
        else:
            is_active = await self.bot.db.get_bot_setting("maintenance_mode", "0") == "1"
            status_str = "**ВКЛЮЧЕНО (ОТКЛЮЧЁН)** 🛠️" if is_active else "**ВЫКЛЮЧЕНО (В СЕТИ)** 🟢"
            view = make_text_container(
                f"### {emojis.INFO} Статус веб-дашборда\n"
                f"{emojis.DOT} Текущий статус: {status_str}\n"
                f"{emojis.DOT} Использование: `{ctx.prefix}maintenance on` | `{ctx.prefix}maintenance off`"
            )
        await ctx.reply(view=view)


async def setup(bot):
    await bot.add_cog(Owner(bot))