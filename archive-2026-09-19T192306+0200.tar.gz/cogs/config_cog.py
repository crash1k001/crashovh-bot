import discord
from discord.ext import commands
from discord import ui
from config import Config
import emojis


def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view


class TwoFourSevenLayout(ui.LayoutView):
    def __init__(self, bot, ctx, current):
        super().__init__(timeout=60)
        self.bot = bot
        self.ctx = ctx
        self.current = current
        self.message = None
        self.rebuild()

    def rebuild(self):
        self.clear_items()
        container = ui.Container(accent_colour=None)

        status = "Включён" if self.current else "Выключен"
        container.add_item(ui.TextDisplay(f"### Режим 24/7"))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(
            f"{emojis.DOT} **Статус:** `{status}`\n"
            f"{emojis.DOT} **Изменил:** {self.ctx.author.mention}\n\n"
            f"Когда включено, бот не будет автоматически отключаться от голосового канала."
        ))
        container.add_item(ui.Separator())

        row = ui.ActionRow()
        enable_style = discord.ButtonStyle.success if not self.current else discord.ButtonStyle.secondary
        disable_style = discord.ButtonStyle.danger if self.current else discord.ButtonStyle.secondary

        enable_btn = ToggleBtn("enable", "Включить", enable_style, self, disabled=self.current)
        disable_btn = ToggleBtn("disable", "Выключить", disable_style, self, disabled=not self.current)
        row.add_item(enable_btn)
        row.add_item(disable_btn)
        container.add_item(row)

        self.add_item(container)


class ToggleBtn(ui.Button):
    def __init__(self, action, label, style, layout, disabled=False):
        super().__init__(label=label, style=style, disabled=disabled)
        self.action = action
        self.layout = layout

    async def callback(self, interaction):
        if interaction.user.id != self.layout.ctx.author.id:
            return await interaction.response.send_message("Это не для тебя.", ephemeral=True)
        value = self.action == "enable"
        guild_id = self.layout.ctx.guild.id
        await self.layout.bot.db.set_247(guild_id, value)
        if value:
            vc = self.layout.ctx.guild.voice_client
            if vc and vc.channel:
                await self.layout.bot.db.set_247_channel(guild_id, vc.channel.id)
        self.layout.current = value
        self.layout.rebuild()
        await interaction.response.edit_message(view=self.layout)


class ConfigCog(commands.Cog, name="Config"):
    """Команды настройки сервера."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="247")
    @commands.guild_only()
    async def twentyfourseven(self, ctx, channel: discord.VoiceChannel = None):
        """Переключить режим 24/7 или задать голосовой канал для него."""
        if channel:
            perms = channel.permissions_for(ctx.guild.me)
            if not perms.connect or not perms.speak:
                return await ctx.reply(view=make_text_container(f"{emojis.ERROR} Мне нужны права Подключение и Говорить в канале `{channel.name}`."))
            
            await self.bot.db.set_247(ctx.guild.id, True)
            await self.bot.db.set_247_channel(ctx.guild.id, channel.id)
            return await ctx.reply(view=make_text_container(f"{emojis.SUCCESS} Режим 24/7 **включён** для голосового канала **{channel.name}**!"))

        current = await self.bot.db.get_247(ctx.guild.id)
        layout = TwoFourSevenLayout(self.bot, ctx, current)
        msg = await ctx.reply(view=layout)
        layout.message = msg

    @commands.hybrid_command(name="setprefix", aliases=["prefix"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def setprefix(self, ctx, *, new_prefix: str):
        """Изменить префикс сервера."""
        if len(new_prefix) > 5:
            view = make_text_container(f"{emojis.ERROR} Префикс должен быть не длиннее 5 символов.")
            return await ctx.reply(view=view)
        await self.bot.db.set_prefix(ctx.guild.id, new_prefix)
        text = (
            f"### {emojis.SUCCESS} Префикс обновлён\n"
            f"{emojis.DOT} Новый префикс: `{new_prefix}`\n"
            f"{emojis.DOT} Пример: `{new_prefix}play <song>`"
        )
        view = make_text_container(text)
        await ctx.reply(view=view)



    @commands.hybrid_command(name="settings", aliases=["config", "serverconfig"])
    @commands.guild_only()
    async def settings_cmd(self, ctx):
        """Посмотреть текущие настройки сервера."""
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        
        dj_role_str = f"<@&{s['dj_role_id']}>" if s.get("dj_role_id") else "`Нет (все)`"
        vc_str = f"<#{s['restricted_vc_id']}>" if s.get("restricted_vc_id") else "`Все голосовые каналы`"
        tc_str = f"<#{s['restricted_tc_id']}>" if s.get("restricted_tc_id") else "`Все текстовые каналы`"
        mode_247 = "`Включён`" if s.get("twentyfourseven") else "`Выключен`"
        announce_str = "`Включено`" if s.get("announce_now_playing") else "`Выключено`"

        text = (
            f"### {emojis.CAT_CONFIG} Настройки сервера **{ctx.guild.name}**\n"
            f"{emojis.DOT} **Префикс:** `{s['prefix']}`\n"
            f"{emojis.DOT} **Режим 24/7:** {mode_247}\n"
            f"{emojis.DOT} **Громкость по умолчанию:** `{s['default_volume']}%`\n"
            f"{emojis.DOT} **Анонс треков:** {announce_str}\n"
            f"{emojis.DOT} **Роль DJ:** {dj_role_str}\n"
            f"{emojis.DOT} **Ограниченный голосовой канал:** {vc_str}\n"
            f"{emojis.DOT} **Ограниченный текстовый канал:** {tc_str}\n\n"
            f"-# *Настраивай параметры через веб-дашборд или командами на сервере.*"
        )
        view = make_text_container(text)
        await ctx.reply(view=view)

    @commands.hybrid_command(name="setdefaultvolume", aliases=["defaultvolume", "defvol"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def setdefaultvolume(self, ctx, volume: int):
        """Задать громкость воспроизведения по умолчанию (0% - 150%)."""
        vol = max(0, min(150, volume))
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        await self.bot.db.update_guild_settings(
            guild_id=ctx.guild.id,
            prefix=s["prefix"],
            twentyfourseven=s["twentyfourseven"],
            twentyfourseven_channel_id=s.get("twentyfourseven_channel_id"),
            default_volume=vol,
            announce_now_playing=s["announce_now_playing"],
            dj_role_id=s["dj_role_id"],
            restricted_vc_id=s["restricted_vc_id"],
            restricted_tc_id=s["restricted_tc_id"]
        )
        view = make_text_container(f"{emojis.SUCCESS} Громкость по умолчанию установлена: `{vol}%`")
        await ctx.reply(view=view)

    @commands.hybrid_command(name="announcenowplaying", aliases=["announcenp"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def announcenowplaying(self, ctx):
        """Переключить анонс карточек текущего трека."""
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        new_val = not s["announce_now_playing"]
        await self.bot.db.update_guild_settings(
            guild_id=ctx.guild.id,
            prefix=s["prefix"],
            twentyfourseven=s["twentyfourseven"],
            twentyfourseven_channel_id=s.get("twentyfourseven_channel_id"),
            default_volume=s["default_volume"],
            announce_now_playing=new_val,
            dj_role_id=s["dj_role_id"],
            restricted_vc_id=s["restricted_vc_id"],
            restricted_tc_id=s["restricted_tc_id"]
        )
        state_str = "включён" if new_val else "выключен"
        view = make_text_container(f"{emojis.SUCCESS} Анонс карточек текущего трека теперь **{state_str}**.")
        await ctx.reply(view=view)

    @commands.hybrid_command(name="djrole", aliases=["setdj", "setdjrole", "removedj", "cleardj"])
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def djrole(self, ctx, role: discord.Role = None):
        """Задать или снять роль DJ для музыкальных команд."""
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        role_id = role.id if role else None
        await self.bot.db.update_guild_settings(
            guild_id=ctx.guild.id,
            prefix=s["prefix"],
            twentyfourseven=s["twentyfourseven"],
            twentyfourseven_channel_id=s.get("twentyfourseven_channel_id"),
            default_volume=s["default_volume"],
            announce_now_playing=s["announce_now_playing"],
            dj_role_id=role_id,
            restricted_vc_id=s["restricted_vc_id"],
            restricted_tc_id=s["restricted_tc_id"]
        )
        msg = f"Роль DJ установлена: {role.mention}." if role else "Требование роли DJ снято."
        view = make_text_container(f"{emojis.SUCCESS} {msg}")
        await ctx.reply(view=view)

    @commands.hybrid_command(name="restrictvc")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def restrictvc(self, ctx, channel: discord.VoiceChannel = None):
        """Ограничить воспроизведение музыки конкретным голосовым каналом."""
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        vc_id = channel.id if channel else None
        await self.bot.db.update_guild_settings(
            guild_id=ctx.guild.id,
            prefix=s["prefix"],
            twentyfourseven=s["twentyfourseven"],
            twentyfourseven_channel_id=s.get("twentyfourseven_channel_id"),
            default_volume=s["default_volume"],
            announce_now_playing=s["announce_now_playing"],
            dj_role_id=s["dj_role_id"],
            restricted_vc_id=vc_id,
            restricted_tc_id=s["restricted_tc_id"]
        )
        msg = f"Воспроизведение ограничено каналом {channel.mention}." if channel else "Ограничение голосового канала снято."
        view = make_text_container(f"{emojis.SUCCESS} {msg}")
        await ctx.reply(view=view)

    @commands.hybrid_command(name="restricttc")
    @commands.guild_only()
    @commands.has_permissions(manage_guild=True)
    async def restricttc(self, ctx, channel: discord.TextChannel = None):
        """Ограничить текстовые команды бота конкретным каналом."""
        s = await self.bot.db.get_guild_settings(ctx.guild.id)
        tc_id = channel.id if channel else None
        await self.bot.db.update_guild_settings(
            guild_id=ctx.guild.id,
            prefix=s["prefix"],
            twentyfourseven=s["twentyfourseven"],
            twentyfourseven_channel_id=s.get("twentyfourseven_channel_id"),
            default_volume=s["default_volume"],
            announce_now_playing=s["announce_now_playing"],
            dj_role_id=s["dj_role_id"],
            restricted_vc_id=s["restricted_vc_id"],
            restricted_tc_id=tc_id
        )
        msg = f"Команды ограничены каналом {channel.mention}." if channel else "Ограничение текстового канала снято."
        view = make_text_container(f"{emojis.SUCCESS} {msg}")
        await ctx.reply(view=view)


async def setup(bot):
    await bot.add_cog(ConfigCog(bot))