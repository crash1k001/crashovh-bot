import discord
from discord.ext import commands
from discord import ui
import time
import platform
import psutil
from config import Config
import emojis


# helpers

def make_text_container(text: str) -> ui.LayoutView:
    view = ui.LayoutView()
    container = ui.Container(accent_colour=None)
    container.add_item(ui.TextDisplay(text))
    view.add_item(container)
    return view


def make_progress_bar(percent: float, length: int = 10) -> str:
    percent = max(0.0, min(100.0, percent))
    filled = int(round((percent / 100.0) * length))
    bar = "█" * filled + "░" * (length - filled)
    return f"`[{bar}] {percent:.1f}%`"


def format_uptime(seconds: int) -> str:
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0 or days > 0:
        parts.append(f"{hours}h")
    if minutes > 0 or hours > 0 or days > 0:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def get_latency_badge(latency_ms: int) -> str:
    if latency_ms < 100:
        return f"{emojis.SUCCESS} **Отлично**"
    elif latency_ms < 250:
        return f"{emojis.INFO} **Хорошо**"
    else:
        return f"{emojis.ERROR} **Высокая задержка**"


# help menu layout

class HelpCategorySelect(ui.Select):
    def __init__(self, bot, ctx, layout):
        self.bot_ref = bot
        self.ctx = ctx
        self.layout = layout
        options = [
            discord.SelectOption(label="Главная", value="home", description="Вернуться к общему обзору помощи", emoji=emojis.Echo),
            discord.SelectOption(label="Модуль музыки", value="Music", description="Воспроизведение 320kbps, EQ-фильтры и управление голосом", emoji=emojis.CAT_MUSIC),
            discord.SelectOption(label="Плейлисты", value="Playlist", description="Пользовательские плейлисты и управление треками", emoji=emojis.MYMUSIC),
            discord.SelectOption(label="Настройки сервера", value="Config", description="Режим 24/7 и настройка префикса", emoji=emojis.CAT_CONFIG),
            discord.SelectOption(label="Информация о боте", value="Information", description="Статистика системы, задержка, поддержка и приглашение", emoji=emojis.CAT_INFO),
            discord.SelectOption(label="Утилиты", value="Utility", description="Инструменты пользователя, сервера, аватара и баннера", emoji=emojis.CAT_UTILITY),
        ]
        super().__init__(placeholder="Выберите категорию...", options=options)

    async def callback(self, interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("Это меню помощи было вызвано другим пользователем.", ephemeral=True)
        self.layout.current = self.values[0]
        self.layout.rebuild()
        await interaction.response.edit_message(view=self.layout)


class HelpLayout(ui.LayoutView):
    def __init__(self, bot, ctx, prefix: str):
        super().__init__(timeout=120)
        self.bot_ref = bot
        self.ctx = ctx
        self.prefix = prefix
        self.current = "home"
        self.message = None
        self.rebuild()

    def rebuild(self):
        self.clear_items()
        container = ui.Container(accent_colour=None)

        if self.current == "home":
            self._build_home(container)
        else:
            self._build_category(container, self.current)

        container.add_item(ui.Separator())
        row = ui.ActionRow()
        row.add_item(HelpCategorySelect(self.bot_ref, self.ctx, self))
        container.add_item(row)

        self.add_item(container)

    def _build_home(self, container):
        prefix = self.prefix
        non_hidden_cmds = [c for c in self.bot_ref.commands if not c.hidden]
        bot_name = self.bot_ref.user.name if (self.bot_ref and self.bot_ref.user) else "Echo"
        dash_url = getattr(Config, "DASHBOARD_URL", "http://localhost:3000")

        container.add_item(ui.TextDisplay(f"### {emojis.Echo} **{bot_name} — Справочный центр**"))
        container.add_item(ui.TextDisplay(
            f"*{emojis.MUSIC} 320kbps Lossless аудио • Режим 24/7 • Веб-дашборд*\n"
            f"{emojis.DOT} **Префикс:** `{prefix}`  •  **Команд:** `{len(non_hidden_cmds)}` активно  •  [Веб-консоль]({dash_url})"
        ))
        container.add_item(ui.Separator())

        music_cmds = len([c for c in self.bot_ref.commands if c.cog_name == "Music" and not c.hidden])
        pl_cmds = len([c for c in self.bot_ref.commands if c.cog_name == "Playlist" and not c.hidden])
        cfg_cmds = len([c for c in self.bot_ref.commands if c.cog_name == "Config" and not c.hidden])
        info_cmds = len([c for c in self.bot_ref.commands if c.cog_name == "Information" and not c.hidden])
        util_cmds = len([c for c in self.bot_ref.commands if c.cog_name == "Utility" and not c.hidden])

        overview = (
            f"{emojis.CAT_MUSIC} **Музыкальная консоль** — `{music_cmds}` команд\n"
            f"↳ *Воспроизведение, 8D EQ-фильтры, управление очередью и режим 24/7*\n\n"
            f"{emojis.MYMUSIC} **Плейлисты** — `{pl_cmds}` команд\n"
            f"↳ *Пользовательские плейлисты и управление треками*\n\n"
            f"{emojis.CAT_CONFIG} **Настройки сервера** — `{cfg_cmds}` команд\n"
            f"↳ *Настройка префикса сервера и голосовых параметров*\n\n"
            f"{emojis.CAT_INFO} **Информация** — `{info_cmds}` команд\n"
            f"↳ *Пинг задержки, статистика системы и сервер поддержки*\n\n"
            f"{emojis.CAT_UTILITY} **Утилиты** — `{util_cmds}` команд\n"
            f"↳ *Аватары, баннеры, инфо о сервере и число участников*"
        )
        container.add_item(ui.TextDisplay(overview))
        container.add_item(ui.TextDisplay(f"-# Выберите категорию ниже, чтобы посмотреть команды."))

    def _build_category(self, container, category):
        cat_emojis = {
            "Music": emojis.CAT_MUSIC,
            "Playlist": emojis.MYMUSIC,
            "Config": emojis.CAT_CONFIG,
            "Information": emojis.CAT_INFO,
            "Utility": emojis.CAT_UTILITY,
        }
        ce = cat_emojis.get(category, emojis.DOT)
        container.add_item(ui.TextDisplay(f"### {ce} **Модуль: {category}**"))
        container.add_item(ui.Separator())

        cmds = [c for c in self.bot_ref.commands if (c.cog_name or "Other") == category and not c.hidden]
        if not cmds:
            container.add_item(ui.TextDisplay(f"{emojis.INFO} В этом модуле пока нет активных команд."))
            return

        lines = []
        for c in sorted(cmds, key=lambda x: x.name):
            aliases = f" *(alias: `{', '.join(c.aliases)}`)*" if c.aliases else ""
            h_text = c.help.split('\n')[0] if c.help else "Выполнить команду."
            if len(h_text) > 42:
                h_text = h_text[:39] + "..."
            lines.append(f"{emojis.DOT} **`/{c.name}`**{aliases} — *{h_text}*")
            
        container.add_item(ui.TextDisplay("\n".join(lines)))
        container.add_item(ui.Separator())
        container.add_item(ui.TextDisplay(f"-# **Всего команд:** `{len(cmds)}` в категории **{category}**"))


# stats layout

class StatsSelect(ui.Select):
    def __init__(self, bot, ctx, layout):
        self.bot_ref = bot
        self.ctx = ctx
        self.layout = layout
        options = [
            discord.SelectOption(
                label="Обзор",
                value="overview",
                description="Охват серверов, голосовые потоки, задержка и аптайм",
                emoji=emojis.Echo
            ),
            discord.SelectOption(
                label="Производительность системы",
                value="system",
                description="Загрузка CPU, использование RAM, ядра и хост-ОС",
                emoji=emojis.CAT_UTILITY
            ),
            discord.SelectOption(
                label="Кластер Lavalink",
                value="lavalink",
                description="Подключения аудио-нод, активные плееры и память",
                emoji=emojis.MUSIC
            ),
            discord.SelectOption(
                label="Архитектура и сеть",
                value="architecture",
                description="Идентификация бота, владелец, шарды и состояние БД",
                emoji=emojis.CAT_INFO
            ),
        ]
        super().__init__(placeholder="Выберите раздел статистики...", options=options)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("Это меню статистики было вызвано другим пользователем.", ephemeral=True)
        self.layout.current = self.values[0]
        self.layout.rebuild()
        await interaction.response.edit_message(view=self.layout)


class RefreshStatsBtn(ui.Button):
    def __init__(self, layout):
        super().__init__(style=discord.ButtonStyle.secondary, label="Обновить", emoji="🔄")
        self.layout = layout

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.layout.ctx.author.id:
            return await interaction.response.send_message("Это меню статистики было вызвано другим пользователем.", ephemeral=True)
        self.layout.rebuild()
        await interaction.response.edit_message(view=self.layout)


class StatsLayout(ui.LayoutView):
    def __init__(self, bot, ctx):
        super().__init__(timeout=120)
        self.bot_ref = bot
        self.ctx = ctx
        self.current = "overview"
        self.message = None
        self.rebuild()

    def rebuild(self):
        self.clear_items()
        container = ui.Container(accent_colour=0x5865F2)

        if self.current == "overview":
            self._overview(container)
        elif self.current == "system":
            self._system(container)
        elif self.current == "lavalink":
            self._lavalink(container)
        else:
            self._architecture(container)

        container.add_item(ui.Separator())

        row_select = ui.ActionRow()
        row_select.add_item(StatsSelect(self.bot_ref, self.ctx, self))
        container.add_item(row_select)

        row_btns = ui.ActionRow()
        row_btns.add_item(RefreshStatsBtn(self))

        dash_url = getattr(Config, "DASHBOARD_URL", None)
        if dash_url:
            row_btns.add_item(ui.Button(label="Веб-дашборд", url=dash_url, style=discord.ButtonStyle.link, emoji="🌐"))

        if getattr(Config, "SUPPORT_SERVER", None):
            row_btns.add_item(ui.Button(label="Сервер поддержки", url=Config.SUPPORT_SERVER, style=discord.ButtonStyle.link, emoji="💬"))

        container.add_item(row_btns)
        self.add_item(container)

    def _overview(self, container):
        bot = self.bot_ref
        guilds = len(bot.guilds)
        users = sum((g.member_count or 0) for g in bot.guilds)
        channels = sum(1 for _ in bot.get_all_channels())
        commands_count = len([c for c in bot.commands if not c.hidden])

        uptime_sec = int(time.time() - getattr(bot, "start_time", time.time()))
        uptime_str = format_uptime(uptime_sec)

        vcs = 0
        for vc in bot.voice_clients:
            try:
                conn_attr = getattr(vc, 'is_connected', None)
                if (callable(conn_attr) and conn_attr()) or (not callable(conn_attr) and conn_attr):
                    vcs += 1
            except Exception:
                pass

        playing_players = 0
        music_cog = bot.get_cog("Music")
        if music_cog and getattr(music_cog, "lavalink", None):
            try:
                playing_players = len([p for p in music_cog.lavalink.player_manager.players.values() if getattr(p, "is_playing", False)])
            except Exception:
                pass

        api_ms = round(bot.latency * 1000)
        badge = get_latency_badge(api_ms)
        shards = bot.shard_count or 1

        header_text = ui.TextDisplay(
            f"### {emojis.Echo} **{bot.user.name} — Телеметрия и работа**\n"
            f"-# *Аудио-движок Lossless 320kbps • Обзор телеметрии в реальном времени*"
        )
        try:
            bot_avatar_url = bot.user.display_avatar.url
            header_section = ui.Section(
                header_text,
                accessory=ui.Thumbnail(media=discord.UnfurledMediaItem(url=str(bot_avatar_url)))
            )
            container.add_item(header_section)
        except Exception:
            container.add_item(header_text)

        container.add_item(ui.Separator())

        overview_text = (
            f"### 📊 **Общий охват**\n"
            f"{emojis.DOT} **Серверов:** `{guilds:,}`\n"
            f"{emojis.DOT} **Всего пользователей:** `{users:,}`\n"
            f"{emojis.DOT} **Отслеживается каналов:** `{channels:,}`\n"
            f"{emojis.DOT} **Зарегистрировано команд:** `{commands_count}`\n\n"
            f"### 🎵 **Аудио-потоки и подключения**\n"
            f"{emojis.DOT} **Активные голосовые каналы:** `{vcs}`\n"
            f"{emojis.DOT} **Активные музыкальные потоки:** `{playing_players}`\n\n"
            f"### ⚡ **Системная телеметрия**\n"
            f"{emojis.DOT} **Задержка API:** `{api_ms}ms` ({badge})\n"
            f"{emojis.DOT} **Активных шардов:** `{shards}`\n"
            f"{emojis.DOT} **Аптайм системы:** `{uptime_str}`"
        )
        container.add_item(ui.TextDisplay(overview_text))
        container.add_item(ui.TextDisplay(f"-# Используйте меню ниже, чтобы переключить раздел телеметрии."))

    def _system(self, container):
        proc = psutil.Process()
        mem = proc.memory_info()
        ram_mb = mem.rss / (1024 * 1024)
        sys_mem = psutil.virtual_memory()
        total_ram_gb = sys_mem.total / (1024 * 1024 * 1024)
        ram_pct = (mem.rss / sys_mem.total) * 100.0

        try:
            cpu_pct = proc.cpu_percent(interval=None)
        except Exception:
            cpu_pct = psutil.cpu_percent()
        
        cpu_cores = psutil.cpu_count(logical=True)
        threads = proc.num_threads()

        cpu_bar = make_progress_bar(cpu_pct, 12)
        ram_bar = make_progress_bar(ram_pct, 12)

        container.add_item(ui.TextDisplay(f"### {emojis.CAT_UTILITY} **Аппаратные и системные метрики**"))
        container.add_item(ui.TextDisplay(f"*Нагрузка хост-сервера, выделение RAM и движок выполнения в реальном времени*"))
        container.add_item(ui.Separator())

        sys_text = (
            f"### {emojis.RAM} **Использование памяти (RAM)**\n"
            f"{emojis.DOT} **Занято процессом:** `{ram_mb:.1f} MB` / `{total_ram_gb:.1f} GB`\n"
            f"{emojis.DOT} **Уровень использования:** {ram_bar}\n\n"
            f"### {emojis.CPU} **Обработка CPU**\n"
            f"{emojis.DOT} **Загрузка CPU:** `{cpu_pct:.1f}%` (`{cpu_cores}` ядер)\n"
            f"{emojis.DOT} **Вычислительная нагрузка:** {cpu_bar}\n"
            f"{emojis.DOT} **Активных потоков:** `{threads}`\n\n"
            f"### {emojis.TERMINAL} **Среда выполнения**\n"
            f"{emojis.DOT} **Хост-ОС:** `{platform.system()} {platform.release()}` ({platform.machine()})\n"
            f"{emojis.DOT} **Python:** `{platform.python_version()}`\n"
            f"{emojis.DOT} **Библиотека discord.py:** `{discord.__version__}`"
        )
        container.add_item(ui.TextDisplay(sys_text))
        container.add_item(ui.TextDisplay(f"-# Нажмите «Обновить», чтобы обновить данные в реальном времени."))

    def _lavalink(self, container):
        container.add_item(ui.TextDisplay(f"### {emojis.MUSIC} **Аудио-кластер Lavalink**"))
        container.add_item(ui.TextDisplay(f"*Ноды аудиопотоков высокого качества и статус кластера воспроизведения*"))
        container.add_item(ui.Separator())

        music_cog = self.bot_ref.get_cog("Music")
        if not music_cog or not getattr(music_cog, "lavalink", None):
            container.add_item(ui.TextDisplay(f"{emojis.INFO} Клиент Lavalink не инициализирован."))
            return

        nodes = music_cog.lavalink.node_manager.nodes
        if not nodes:
            container.add_item(ui.TextDisplay(f"{emojis.INFO} Аудио-ноды не настроены."))
            return

        node_blocks = []
        for node in nodes:
            is_avail = getattr(node, "available", False)
            status = f"{emojis.SUCCESS} **В сети**" if is_avail else f"{emojis.ERROR} **Не в сети**"
            players = [p for p in music_cog.lavalink.player_manager.players.values() if getattr(p, "node", None) == node]
            playing = [p for p in players if getattr(p, "is_playing", False)]
            
            stats = getattr(node, "stats", None)
            if stats and is_avail:
                uptime_ms = getattr(stats, "uptime", 0) // 1000
                node_up = format_uptime(uptime_ms)
                mem_used = getattr(stats, "memory_used", 0) / (1024 * 1024)
                mem_alloc = getattr(stats, "memory_allocated", 0) / (1024 * 1024)
                lavalink_load = getattr(stats, "lavalink_load", 0) * 100
                
                node_text = (
                    f"**Нода:** `{node.name}` ({status})\n"
                    f"{emojis.DOT} **Адрес:** `{node.host}:{node.port}`\n"
                    f"{emojis.DOT} **Плееров:** `{len(players)}` всего (`{len(playing)}` активно стримят)\n"
                    f"{emojis.DOT} **Аптайм ноды:** `{node_up}`\n"
                    f"{emojis.DOT} **Нагрузка ноды:** `{lavalink_load:.1f}%` CPU  •  **RAM:** `{mem_used:.1f} MB` / `{mem_alloc:.1f} MB`"
                )
            else:
                node_text = (
                    f"**Нода:** `{node.name}` ({status})\n"
                    f"{emojis.DOT} **Адрес:** `{node.host}:{node.port}`\n"
                    f"{emojis.DOT} **Плееров:** `{len(players)}` всего (`{len(playing)}` стримят)"
                )
            node_blocks.append(node_text)

        container.add_item(ui.TextDisplay("\n\n".join(node_blocks)))

    def _architecture(self, container):
        bot = self.bot_ref
        owner_name = "Разработчик бота"
        if getattr(bot, "owner_id", None):
            owner_u = bot.get_user(bot.owner_id)
            if owner_u:
                owner_name = f"{owner_u.name}"

        start_ts = int(getattr(bot, "start_time", time.time()))

        container.add_item(ui.TextDisplay(f"### {emojis.CAT_INFO} **Архитектура и сетевая телеметрия**"))
        container.add_item(ui.TextDisplay(f"*Идентификация бота, маршрутизация инфраструктуры и состояние БД*"))
        container.add_item(ui.Separator())

        arch_text = (
            f"### 🛡️ **Идентификация и владение**\n"
            f"{emojis.DOT} **Приложение:** `{bot.user.name}`\n"
            f"{emojis.DOT} **ID приложения:** `{bot.user.id}`\n"
            f"{emojis.CROWN} **Владелец бота:** `{owner_name}`\n"
            f"{emojis.DOT} **В сети с:** <t:{start_ts}:F> (<t:{start_ts}:R>)\n\n"
            f"### {emojis.SHARD} **Сеть и маршрутизация**\n"
            f"{emojis.DOT} **Количество шардов:** `{bot.shard_count or 1}`\n"
            f"{emojis.DOT} **Задержка Gateway API:** `{round(bot.latency * 1000)}ms`\n"
            f"{emojis.DOT} **Подключение к БД:** {emojis.SUCCESS} **Активно и в порядке**\n"
            f"{emojis.DOT} **Префикс по умолчанию:** `{Config.DEFAULT_PREFIX}`"
        )
        container.add_item(ui.TextDisplay(arch_text))


class PingLayout(ui.LayoutView):
    def __init__(self, bot, ctx, initial_mlat: int = 0):
        super().__init__(timeout=120)
        self.bot_ref = bot
        self.ctx = ctx
        self.mlat = initial_mlat
        self.rebuild()

    def rebuild(self):
        self.clear_items()
        container = ui.Container(accent_colour=None)

        bot = self.bot_ref
        api = round(bot.latency * 1000)
        uptime = int(time.time() - getattr(bot, "start_time", time.time()))
        h, m, s = uptime // 3600, (uptime % 3600) // 60, uptime % 60

        if api < 150:
            status_badge = f"{emojis.SUCCESS} **Отличное соединение**"
        elif api < 350:
            status_badge = f"{emojis.INFO} **Хороший сигнал**"
        else:
            status_badge = f"{emojis.ERROR} **Высокая задержка**"

        container.add_item(ui.TextDisplay(f"### {emojis.Echo} **Понг! Телеметрия активна**"))
        container.add_item(ui.Separator())

        mlat_text = f"`{self.mlat}ms`" if self.mlat > 0 else "`измеряю...`"

        text = (
            f"{emojis.DOT} **Пинг Gateway API:** `{api}ms`  •  {status_badge}\n"
            f"{emojis.DOT} **Время туда-обратно:** {mlat_text}\n"
            f"{emojis.DOT} **Аптайм движка:** `{h}ч {m}м {s}с`\n"
            f"{emojis.DOT} **Активных команд:** `{len(bot.commands)}` зарегистрировано"
        )
        container.add_item(ui.TextDisplay(text))
        container.add_item(ui.Separator())

        row = ui.ActionRow()
        row.add_item(RePingButton(self.bot_ref, self.ctx, self))
        container.add_item(row)

        self.add_item(container)


class RePingButton(ui.Button):
    def __init__(self, bot, ctx, layout):
        self.bot_ref = bot
        self.ctx = ctx
        self.layout = layout
        super().__init__(style=discord.ButtonStyle.secondary, label="Пинг заново", emoji=emojis.RELOAD)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("Запусти /ping, чтобы измерить свою задержку.", ephemeral=True)
        
        start = time.perf_counter()
        await interaction.response.defer()
        end = time.perf_counter()
        
        mlat = round((end - start) * 1000)
        self.layout.mlat = mlat
        self.layout.rebuild()
        await interaction.edit_original_response(view=self.layout)


class Info(commands.Cog, name="Information"):
    """Информация и статистика бота."""

    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", aliases=["h"])
    async def help_cmd(self, ctx, *, command: str = None):
        """Показать меню помощи или детали команды."""
        prefix = Config.DEFAULT_PREFIX
        if ctx.guild:
            prefix = await self.bot.db.get_prefix(ctx.guild.id) or Config.DEFAULT_PREFIX

        if command:
            cmd = self.bot.get_command(command)
            if not cmd:
                view = make_text_container(f"{emojis.ERROR} Команда `{command}` не найдена.")
                return await ctx.reply(view=view)
            aliases = ", ".join(f"`{a}`" for a in cmd.aliases) if cmd.aliases else "`Нет`"
            text = (
                f"### Команда: {cmd.name}\n"
                f"{emojis.DOT} **Категория:** `{cmd.cog_name or 'Нет'}`\n"
                f"{emojis.DOT} **Описание:** {cmd.help or 'Нет описания'}\n"
                f"{emojis.DOT} **Алиасы:** {aliases}\n"
                f"{emojis.DOT} **Использование:** `{prefix}{cmd.qualified_name} {cmd.signature}`"
            )
            view = make_text_container(text)
            return await ctx.reply(view=view)

        layout = HelpLayout(self.bot, ctx, prefix)
        msg = await ctx.reply(view=layout)
        layout.message = msg

    @commands.hybrid_command(name="ping")
    async def ping(self, ctx):
        """Проверить задержку сети и телеметрию кластера."""
        start = time.perf_counter()
        loading = make_text_container(f"{emojis.LOADING} Измеряю задержку сети...")
        msg = await ctx.reply(view=loading)
        end = time.perf_counter()
        mlat = round((end - start) * 1000)

        layout = PingLayout(self.bot, ctx, initial_mlat=mlat)
        await msg.edit(view=layout)

    @commands.hybrid_command(name="stats", aliases=["botinfo", "bi"])
    async def stats(self, ctx):
        """Подробная статистика бота."""
        layout = StatsLayout(self.bot, ctx)
        msg = await ctx.reply(view=layout)
        layout.message = msg

    @commands.hybrid_command(name="invite")
    async def invite(self, ctx):
        """Получить ссылку для приглашения бота."""
        url = discord.utils.oauth_url(self.bot.user.id, permissions=discord.Permissions(8))
        layout = ui.LayoutView()
        container = ui.Container(accent_colour=None)
        container.add_item(ui.TextDisplay(f"### {emojis.INFO} Пригласить {self.bot.user.name} на свой сервер"))
        container.add_item(ui.Separator())
        row = ui.ActionRow()
        row.add_item(ui.Button(label="Пригласить", url=url, style=discord.ButtonStyle.link))
        if Config.SUPPORT_SERVER:
            row.add_item(ui.Button(label="Поддержка", url=Config.SUPPORT_SERVER, style=discord.ButtonStyle.link))
        container.add_item(row)
        layout.add_item(container)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="support")
    async def support(self, ctx):
        """Получить ссылку на сервер поддержки."""
        layout = ui.LayoutView()
        container = ui.Container(accent_colour=None)
        container.add_item(ui.TextDisplay("### Нужна помощь? Загляни на наш сервер поддержки."))
        container.add_item(ui.Separator())
        row = ui.ActionRow()
        row.add_item(ui.Button(label="Сервер поддержки", url=Config.SUPPORT_SERVER, style=discord.ButtonStyle.link))
        container.add_item(row)
        layout.add_item(container)
        await ctx.reply(view=layout)

    @commands.hybrid_command(name="membercount", aliases=["mc"])
    async def membercount(self, ctx):
        """Показать количество участников сервера."""
        g = ctx.guild
        bots = sum(1 for m in g.members if m.bot)
        humans = g.member_count - bots
        online = sum(1 for m in g.members if m.status != discord.Status.offline)

        text = (
            f"### Количество участников\n"
            f"```yaml\n"
            f"Всего участников : {g.member_count}\n"
            f"Людей            : {humans}\n"
            f"Ботов            : {bots}\n"
            f"Онлайн           : {online}\n"
            f"```"
        )
        view = make_text_container(text)
        await ctx.reply(view=view)


async def setup(bot):
    await bot.add_cog(Info(bot))