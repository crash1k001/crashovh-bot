
module.exports = {
    JOIN_LOGS:   '', // channel ID — logs when bot joins a server
    LEAVE_LOGS:  '', // channel ID — logs when bot leaves a server
    SLASH_LOGS:  '', // channel ID — logs slash command usage
    PREFIX_LOGS: '', // channel ID — logs prefix command usage
    ERROR_LOGS:  '', // channel ID — logs errors and exceptions
    DM_LOGS:     '', // channel ID — logs DMs sent to the bot
};
